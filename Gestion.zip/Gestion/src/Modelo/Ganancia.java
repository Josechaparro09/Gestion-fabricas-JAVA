package Modelo;

public class Ganancia {
    
}
